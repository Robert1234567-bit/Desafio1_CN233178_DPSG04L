import React from "react";
import SalaCine from "../src/components/SalaCine";
import SelectorSala from "../src/components/SelectorSala";
import ResumenCompra from "../src/components/ResumenCompra";

export default function Home() {
  return (
    <div className="container my-5">
      <h2 className="text-center">Sistema de Venta de Boletos 🎟️</h2>
      <SelectorSala />
      <SalaCine />
      <ResumenCompra />
    </div>
  );
}
