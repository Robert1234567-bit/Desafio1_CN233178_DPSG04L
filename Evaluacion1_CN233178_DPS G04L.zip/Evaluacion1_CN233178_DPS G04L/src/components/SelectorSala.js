import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { cambiarSala } from "../store/salaSlice";

const SelectorSala = () => {
  const dispatch = useDispatch();
  const salaSeleccionada = useSelector((state) => state.salas.salaSeleccionada);

  return (
    <div className="text-center my-3">
      <button
        className={`btn ${salaSeleccionada === 1 ? "btn-primary" : "btn-secondary"} mx-2`}
        onClick={() => dispatch(cambiarSala(1))}
      >
        Sala 1
      </button>
      <button
        className={`btn ${salaSeleccionada === 2 ? "btn-primary" : "btn-secondary"} mx-2`}
        onClick={() => dispatch(cambiarSala(2))}
      >
        Sala 2
      </button>
    </div>
  );
};

export default SelectorSala;
