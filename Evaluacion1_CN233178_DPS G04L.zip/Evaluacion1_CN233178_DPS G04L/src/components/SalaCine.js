import React from "react";
import { useSelector } from "react-redux";
import Asiento from "./Asiento";

const SalaCine = () => {
  const { salas, salaSeleccionada } = useSelector((state) => state.salas);

  return (
    <div className="text-center">
      <h3>Sala {salaSeleccionada}</h3>
      <div className="d-flex flex-wrap justify-content-center">
        {salas[salaSeleccionada].map((ocupado, index) => (
          <Asiento key={index} index={index} ocupado={ocupado} sala={salaSeleccionada} />
        ))}
      </div>
    </div>
  );
};

export default SalaCine;
