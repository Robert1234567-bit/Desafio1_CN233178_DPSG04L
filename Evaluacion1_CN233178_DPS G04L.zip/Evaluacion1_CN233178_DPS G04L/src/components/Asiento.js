import React from "react";
import { useDispatch } from "react-redux";
import { toggleAsiento } from "../store/salaSlice";

const Asiento = ({ ocupado, index, sala }) => {
  const dispatch = useDispatch();

  return (
    <button
      className={`btn ${ocupado ? "btn-danger" : "btn-success"} m-1`}
      onClick={() => dispatch(toggleAsiento({ sala, index }))}
    >
      {index + 1}
    </button>
  );
};

export default Asiento;
