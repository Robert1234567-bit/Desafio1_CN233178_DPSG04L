import React from "react";
import { useSelector } from "react-redux";

const ResumenCompra = () => {
  const { salas, salaSeleccionada } = useSelector((state) => state.salas);
  const totalBoletos = salas[salaSeleccionada].filter((asiento) => asiento).length;
  const precioBoleto = 10; // Precio por boleto
  const totalPagar = totalBoletos * precioBoleto;

  return (
    <div className="alert alert-info text-center">
      <h4>Resumen de Compra</h4>
      <p>Boletos seleccionados: {totalBoletos}</p>
      <p>Total a pagar: ${totalPagar}</p>
    </div>
  );
};

export default ResumenCompra;
