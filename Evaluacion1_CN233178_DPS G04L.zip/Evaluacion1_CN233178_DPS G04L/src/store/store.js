import { configureStore } from "@reduxjs/toolkit";
import salaReducer from "./salaSlice";

export const store = configureStore({
  reducer: {
    salas: salaReducer,
  },
});
