import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  salas: {
    1: Array(25).fill(false), // Sala 1: 25 asientos
    2: Array(25).fill(false), // Sala 2: 25 asientos
  },
  salaSeleccionada: 1,
};

const salaSlice = createSlice({
  name: "salas",
  initialState,
  reducers: {
    toggleAsiento: (state, action) => {
      const { sala, index } = action.payload;
      state.salas[sala][index] = !state.salas[sala][index];
    },
    cambiarSala: (state, action) => {
      state.salaSeleccionada = action.payload;
    },
  },
});

export const { toggleAsiento, cambiarSala } = salaSlice.actions;
export default salaSlice.reducer;
